MUDUNURU MAHASRI - PORTFOLIO WEBSITE

Files:
- index.html
- style.css
- script.js

How to use:
1. Extract the ZIP file.
2. Open index.html in any modern web browser.
3. To publish online, upload these files to GitHub Pages, Netlify, Vercel, or another static hosting service.

Portfolio content was prepared from the supplied resume.
